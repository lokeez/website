<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed'); 

$info = array(
	'name' => 'Chili code highlighter',
	'description' => 'Подсветка кода',
	'version' => 'alpha',
	'author' => 'lokee',
	'plugin_url' => 'http://lokee.rv.ua/page/chili-podsvetka-koda-plagin-dlja-maxsite-cms',
	'author_url' => 'http://lokee.rv.ua/',
	'group' => 'template'
);

?>